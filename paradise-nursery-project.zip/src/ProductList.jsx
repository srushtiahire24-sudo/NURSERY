import { useDispatch, useSelector } from 'react-redux';
import { addItem } from './CartSlice';

const products = [
  { id: 1, name: 'Snake Plant', category: 'Air Purifying', price: 18, image: 'https://images.unsplash.com/photo-1593691509543-c55fb32e5cee?w=600' },
  { id: 2, name: 'Peace Lily', category: 'Air Purifying', price: 22, image: 'https://images.unsplash.com/photo-1593691509543-c55fb32e5cee?w=600' },
  { id: 3, name: 'Spider Plant', category: 'Air Purifying', price: 15, image: 'https://images.unsplash.com/photo-1572688484438-313a6e50c333?w=600' },
  { id: 4, name: 'Aloe Vera', category: 'Medicinal', price: 12, image: 'https://images.unsplash.com/photo-1501004318641-b39e6451bec6?w=600' },
  { id: 5, name: 'Lavender', category: 'Medicinal', price: 16, image: 'https://images.unsplash.com/photo-1499002238440-d264edd596ec?w=600' },
  { id: 6, name: 'Basil', category: 'Medicinal', price: 10, image: 'https://images.unsplash.com/photo-1618164436241-4473940d1f5c?w=600' },
  { id: 7, name: 'Jade Plant', category: 'Easy Care', price: 14, image: 'https://images.unsplash.com/photo-1509423350716-97f9360b4e09?w=600' },
  { id: 8, name: 'Pothos', category: 'Easy Care', price: 13, image: 'https://images.unsplash.com/photo-1614594975525-e45190c55d0b?w=600' },
  { id: 9, name: 'ZZ Plant', category: 'Easy Care', price: 20, image: 'https://images.unsplash.com/photo-1632207691143-643e2f6f6c09?w=600' }
];

export default function ProductList({ onCartClick }) {
  const dispatch = useDispatch();
  const cart = useSelector(state => state.cart.items);
  const categories = [...new Set(products.map(product => product.category))];

  return (
    <main className="page">
      <div className="page-heading">
        <div><p className="eyebrow">Our collection</p><h1>Shop Houseplants</h1></div>
        <button className="primary" onClick={onCartClick}>View Cart ({cart.reduce((n, item) => n + item.quantity, 0)})</button>
      </div>
      {categories.map(category => (
        <section className="category" key={category}>
          <h2>{category} Plants</h2>
          <div className="grid">
            {products.filter(product => product.category === category).map(product => {
              const inCart = cart.find(item => item.id === product.id);
              return (
                <article className="product-card" key={product.id}>
                  <img src={product.image} alt={product.name} />
                  <div className="product-info">
                    <h3>{product.name}</h3><p>${product.price.toFixed(2)}</p>
                    <button className="primary" onClick={() => dispatch(addItem(product))}>
                      {inCart ? `Add another (${inCart.quantity} in cart)` : 'Add to Cart'}
                    </button>
                  </div>
                </article>
              );
            })}
          </div>
        </section>
      ))}
    </main>
  );
}
