import { useDispatch, useSelector } from 'react-redux';
import { removeItem, updateQuantity } from './CartSlice';

export default function CartItem({ onContinueShopping }) {
  const items = useSelector(state => state.cart.items);
  const dispatch = useDispatch();
  const total = items.reduce((sum, item) => sum + item.price * item.quantity, 0);

  return (
    <main className="page">
      <div className="page-heading"><div><p className="eyebrow">Your selection</p><h1>Shopping Cart</h1></div></div>
      {items.length === 0 ? (
        <div className="empty-cart"><h2>Your cart is empty</h2><p>Add some plants to get started.</p>
          <button className="primary" onClick={onContinueShopping}>Continue Shopping</button></div>
      ) : (
        <>
          <div className="cart-list">
            {items.map(item => (
              <article className="cart-row" key={item.id}>
                <img src={item.image} alt={item.name} />
                <div className="cart-detail"><h3>{item.name}</h3><p>${item.price.toFixed(2)} each</p>
                  <div className="quantity">
                    <button aria-label="Decrease quantity" onClick={() => dispatch(updateQuantity({ id: item.id, quantity: item.quantity - 1 }))}>−</button>
                    <span>{item.quantity}</span>
                    <button aria-label="Increase quantity" onClick={() => dispatch(updateQuantity({ id: item.id, quantity: item.quantity + 1 }))}>+</button>
                  </div>
                </div>
                <strong>${(item.price * item.quantity).toFixed(2)}</strong>
                <button className="remove" onClick={() => dispatch(removeItem(item.id))}>Remove</button>
              </article>
            ))}
          </div>
          <div className="cart-summary"><h2>Total: ${total.toFixed(2)}</h2>
            <div className="actions"><button className="secondary" onClick={onContinueShopping}>Continue Shopping</button>
              <button className="primary" onClick={() => window.alert('Checkout coming soon!')}>Checkout</button></div>
          </div>
        </>
      )}
    </main>
  );
}
