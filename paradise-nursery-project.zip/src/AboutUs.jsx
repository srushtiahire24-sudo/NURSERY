export default function AboutUs() {
  return (
    <section className="about">
      <h2>About Paradise Nursery</h2>
      <p>Paradise Nursery makes it easy to bring the beauty of nature into your home.
        We offer a thoughtfully selected collection of houseplants for every space,
        from beginner-friendly greens to statement plants.</p>
      <p>Our mission is to help people create healthier, calmer and greener spaces
        through the joy of plants.</p>
    </section>
  );
}
