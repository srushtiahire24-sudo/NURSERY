import { useState } from 'react';
import { useSelector } from 'react-redux';
import AboutUs from './AboutUs';
import ProductList from './ProductList';
import CartItem from './CartItem';

export default function App() {
  const [page, setPage] = useState('home');
  const items = useSelector(state => state.cart.items);
  const count = items.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div>
      <header className="navbar">
        <button className="brand" onClick={() => setPage('home')}>🌿 Paradise Nursery</button>
        <nav>
          <button onClick={() => setPage('home')}>Home</button>
          <button onClick={() => setPage('plants')}>Plants</button>
          <button onClick={() => setPage('cart')}>Cart ({count})</button>
        </nav>
      </header>

      {page === 'home' && (
        <main className="hero">
          <div className="hero-card">
            <p className="eyebrow">Bring nature home</p>
            <h1>Welcome to Paradise Nursery</h1>
            <p>Where green meets serenity. Find the perfect plants to make your space feel alive.</p>
            <button className="primary" onClick={() => setPage('plants')}>Get Started</button>
          </div>
          <AboutUs />
        </main>
      )}
      {page === 'plants' && <ProductList onCartClick={() => setPage('cart')} />}
      {page === 'cart' && <CartItem onContinueShopping={() => setPage('plants')} />}
    </div>
  );
}
